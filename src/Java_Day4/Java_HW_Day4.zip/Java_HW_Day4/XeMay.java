package Java_Day4.Java_HW_Day4;

public class XeMay extends Xe {
    @Override
    public String getTenXe() {
        return super.getTenXe();
    }

    @Override
    public void setTenXe(String tenXe) {
        super.setTenXe(tenXe);
    }

    @Override
    public String getLoaiXe() {
        return super.getLoaiXe();
    }

    @Override
    public void setLoaiXe(String loaiXe) {
        super.setLoaiXe(loaiXe);
    }

    @Override
    public int getVanTocMax() {
        return super.getVanTocMax();
    }

    @Override
    public void setVanTocMax(int vanTocMax) {
        super.setVanTocMax(vanTocMax);
    }
}
