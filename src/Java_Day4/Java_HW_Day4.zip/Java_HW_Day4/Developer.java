package Java_Day4.Java_HW_Day4;

public class Developer extends Employee{
    @Override
    public long getEmployee_id() {
        return super.getEmployee_id();
    }

    @Override
    public void setEmployee_id(long employee_id) {
        super.setEmployee_id(employee_id);
    }

    @Override
    public String getEmployee_name() {
        return super.getEmployee_name();
    }

    @Override
    public void setEmployee_name(String employee_name) {
        super.setEmployee_name(employee_name);
    }

    @Override
    public double getEmployee_salary() {
        return super.getEmployee_salary();
    }
}
